import { useState, useEffect, useCallback } from "react";

const SUPABASE_URL = "https://utwpumtpgcolkavqbmmh.supabase.co";
const SUPABASE_KEY = "sb_publishable_Y4ktViRftcIlT5hNWmskQg_lvwBSUje";

const headers = () => ({
  "apikey": SUPABASE_KEY,
  "Authorization": `Bearer ${SUPABASE_KEY}`,
  "Content-Type": "application/json",
});

const query = async (table, params = "") => {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}${params}`, { headers: headers() });
  return r.json();
};

const mutate = async (table, method, data, params = "") => {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}${params}`, {
    method,
    headers: { ...headers(), "Prefer": "return=representation" },
    body: JSON.stringify(data),
  });
  return r.json();
};

const CP_ZONA = {
  '57130':'Neza','57138':'Neza','57120':'Neza','57129':'Neza','57100':'Neza','57103':'Neza','57000':'Neza','57010':'Neza','57500':'Neza','57400':'Neza','57300':'Neza','57440':'Neza','57450':'Neza','57600':'Neza','57940':'Neza',
  '07000':'Gustavo A. Madero','07100':'Gustavo A. Madero','07200':'Gustavo A. Madero','07300':'Gustavo A. Madero','07400':'Gustavo A. Madero','07500':'Gustavo A. Madero','07600':'Gustavo A. Madero','07700':'Gustavo A. Madero','07800':'Gustavo A. Madero','07900':'Gustavo A. Madero',
  '15000':'Venustiano Carranza','15100':'Venustiano Carranza','15200':'Venustiano Carranza','15300':'Venustiano Carranza','15400':'Venustiano Carranza','15500':'Venustiano Carranza','15600':'Venustiano Carranza','15700':'Venustiano Carranza','15800':'Venustiano Carranza','15900':'Venustiano Carranza',
  '08000':'Iztacalco','08100':'Iztacalco','08200':'Iztacalco','08300':'Iztacalco','08400':'Iztacalco','08500':'Iztacalco','08600':'Iztacalco','08700':'Iztacalco','08800':'Iztacalco','08900':'Iztacalco',
  '06000':'Cuauhtémoc','06100':'Cuauhtémoc','06200':'Cuauhtémoc','06300':'Cuauhtémoc','06400':'Cuauhtémoc','06500':'Cuauhtémoc','06600':'Cuauhtémoc','06700':'Cuauhtémoc','06800':'Cuauhtémoc','06900':'Cuauhtémoc',
  '55000':'Ecatepec','55100':'Ecatepec','55130':'Ecatepec','55150':'Ecatepec','55160':'Ecatepec','55170':'Ecatepec','55190':'Ecatepec','55200':'Ecatepec','55210':'Ecatepec','55220':'Ecatepec','55230':'Ecatepec','55240':'Ecatepec','55250':'Ecatepec','55260':'Ecatepec','55270':'Ecatepec','55280':'Ecatepec'
};

const CATS = ["Veladoras","Incienso","Protecciones","Hierbas en té","Hierbas para baño","Sales","Esencias y concentrados","Alcoholes","Accesorios","Cuarzos"];
const STATUS_LABELS = { nuevo:"🆕 Nuevo", confirmado:"✅ Confirmado", enviado:"🚚 Enviado", entregado:"🏠 Entregado", cancelado:"❌ Cancelado" };
const STATUS_COLORS = { nuevo:"#c8902a", confirmado:"#2d7a2d", enviado:"#1a6fa0", entregado:"#5a3d8a", cancelado:"#c0392b" };
const PIN_ADMIN = "1234";
const folio = () => "AE" + Date.now().toString(36).toUpperCase().slice(-6);

const GF = `https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,400&family=Jost:wght@300;400;500&display=swap`;

const Toast = ({ msg }) => (
  <div style={{ position:"fixed",bottom:24,left:"50%",transform:"translateX(-50%)",background:"#1a1510",color:"#faf7f2",padding:"10px 22px",borderRadius:50,fontSize:13,zIndex:9999,pointerEvents:"none",whiteSpace:"nowrap",boxShadow:"0 8px 30px rgba(0,0,0,0.3)" }}>{msg}</div>
);

const Spinner = () => (
  <div style={{ display:"flex",alignItems:"center",justifyContent:"center",padding:60 }}>
    <div style={{ width:32,height:32,border:"3px solid #e0d8cc",borderTop:"3px solid #c8902a",borderRadius:"50%",animation:"spin 0.8s linear infinite" }} />
    <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
  </div>
);

// ─── TIENDA ───────────────────────────────────────────────────────────────────
const Tienda = ({ onAdmin }) => {
  const [productos, setProductos] = useState([]);
  const [config, setConfig] = useState({});
  const [filtro, setFiltro] = useState("Todos");
  const [busq, setBusq] = useState("");
  const [carrito, setCarrito] = useState([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [addr, setAddr] = useState({ nombre:"",telefono:"",calle:"",colonia:"",cp:"",alcaldia:"",refs:"" });
  const [cpStatus, setCpStatus] = useState(null);
  const [toast, setToast] = useState("");
  const [loading, setLoading] = useState(true);
  const [enviando, setEnviando] = useState(false);
  const [faqOpen, setFaqOpen] = useState(false);
  const [faqIdx, setFaqIdx] = useState(null);

  const FAQS = [
    { q:"¿Cómo pago?", a:"Pago por transferencia bancaria. Al confirmar tu pedido te enviamos los datos por WhatsApp." },
    { q:"¿A qué zonas entregan?", a:"Sin costo en Neza, Gustavo A. Madero, Venustiano Carranza, Iztacalco, Cuauhtémoc y Ecatepec. Fuera de esa zona enviamos por paquetería." },
    { q:"¿Cuánto tarda el envío?", a:"En zona de cobertura 1–2 días hábiles. Por paquetería 3–5 días." },
    { q:"¿Puedo cancelar mi pedido?", a:"Sí, contáctanos por WhatsApp antes de que el pedido salga a envío." },
    { q:"¿Los productos están consagrados?", a:"Cada producto pasa por una limpieza energética antes de empacarse." },
  ];

  const showToast = msg => { setToast(msg); setTimeout(() => setToast(""), 2500); };

  useEffect(() => {
    (async () => {
      const [prods, cfg] = await Promise.all([
        query("productos", "?select=*&activo=eq.true&order=id.asc"),
        query("config", "?select=clave,valor"),
      ]);
      setProductos(Array.isArray(prods) ? prods : []);
      if (Array.isArray(cfg)) { const m={}; cfg.forEach(r=>m[r.clave]=r.valor); setConfig(m); }
      setLoading(false);
    })();
  }, []);

  const cats = ["Todos", ...CATS.filter(c => productos.some(p => p.categoria===c))];
  const visibles = productos.filter(p => {
    const mc = filtro==="Todos" || p.categoria===filtro;
    const mq = !busq || p.nombre.toLowerCase().includes(busq.toLowerCase());
    return mc && mq;
  });

  const total = carrito.reduce((s,p)=>s+p.precio,0);
  const enCarrito = id => carrito.some(c=>c.id===id);
  const agregar = p => { if(!enCarrito(p.id)){ setCarrito(pr=>[...pr,p]); showToast(`✦ ${p.nombre} añadido`); } };
  const quitar = id => setCarrito(pr=>pr.filter(c=>c.id!==id));

  const verificarCP = cp => {
    setAddr(a=>({...a,cp,alcaldia:CP_ZONA[cp]||""}));
    if(cp.length===5) setCpStatus(CP_ZONA[cp]?"inside":"outside");
    else setCpStatus(null);
  };

  const confirmarPedido = async () => {
    if(!carrito.length) return;
    if(!addr.nombre||!addr.telefono||!addr.calle||!addr.cp){ showToast("⚠️ Completa nombre, teléfono, calle y CP"); return; }
    setEnviando(true);
    try {
      const f = folio();
      const pedido = await mutate("pedidos","POST",{
        folio:f, cliente_nombre:addr.nombre, cliente_telefono:addr.telefono,
        cliente_calle:addr.calle, cliente_colonia:addr.colonia, cliente_cp:addr.cp,
        cliente_alcaldia:addr.alcaldia, cliente_referencias:addr.refs,
        total, tipo_envio:cpStatus==="inside"?"cobertura":"paqueteria", status:"nuevo",
      });
      const pedidoId = Array.isArray(pedido)?pedido[0]?.id:pedido?.id;
      if(pedidoId){
        await mutate("pedido_items","POST", carrito.map(p=>({ pedido_id:pedidoId, producto_id:p.id, nombre:p.nombre, precio:p.precio, cantidad:1 })));
      }
      const lista = carrito.map(p=>`• ${p.nombre} — $${p.precio}`).join("\n");
      const envio = cpStatus==="inside"?"🚚 Envío sin costo":"📦 Envío por paquetería";
      const dir = `${addr.calle}, Col. ${addr.colonia}, CP ${addr.cp}${addr.alcaldia?`, ${addr.alcaldia}`:""}${addr.refs?`\nRefs: ${addr.refs}`:""}`;
      const banco = config.clabe?`\n\n💳 Datos de pago:\n${config.banco||"BBVA"} — CLABE: ${config.clabe}\nTitular: ${config.titular}`:"";
      const msg = encodeURIComponent(`🌙 *NUEVO PEDIDO — Folio ${f}*\n\n${lista}\n\n💰 Total: $${total}\n${envio}\n\n📍 Dirección:\n${dir}\n\n👤 ${addr.nombre} · 📞 ${addr.telefono}${banco}`);
      window.open(`https://wa.me/${config.whatsapp||"525648229075"}?text=${msg}`,"_blank");
      setCarrito([]); setAddr({nombre:"",telefono:"",calle:"",colonia:"",cp:"",alcaldia:"",refs:""}); setCpStatus(null); setDrawerOpen(false);
      showToast(`✅ Pedido ${f} creado`);
    } catch(e){ showToast("Error al crear pedido, intenta de nuevo"); }
    setEnviando(false);
  };

  if(loading) return <div style={{height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#faf7f2",fontFamily:"Georgia,serif",fontSize:"1.5rem",color:"#c8902a"}}>☽ Cargando…</div>;

  return (
    <div style={{fontFamily:"'Jost',sans-serif",background:"#faf7f2",minHeight:"100vh",color:"#2e2416"}}>
      <link href={GF} rel="stylesheet"/>
      {/* NAV */}
      <nav style={{position:"sticky",top:0,zIndex:100,background:"rgba(250,247,242,0.95)",backdropFilter:"blur(12px)",borderBottom:"1px solid #e0d8cc",padding:"0 20px",height:60,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:600}}><span style={{color:"#c8902a"}}>☽</span> Aether<span style={{color:"#c8902a"}}>.</span></div>
        <button onClick={()=>setDrawerOpen(true)} style={{display:"flex",alignItems:"center",gap:8,padding:"7px 16px",border:"1.5px solid #1a1510",borderRadius:50,background:"transparent",cursor:"pointer",fontSize:13,fontFamily:"'Jost',sans-serif",position:"relative"}}>
          🛍 Carrito
          {carrito.length>0 && <span style={{position:"absolute",top:-6,right:-6,width:18,height:18,background:"#c8902a",color:"white",borderRadius:"50%",fontSize:10,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700}}>{carrito.length}</span>}
        </button>
      </nav>

      {/* HERO */}
      <div style={{background:"#1a1208",padding:"70px 20px 60px",textAlign:"center",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse 60% 50% at 40% 50%, rgba(200,144,42,0.15), transparent)"}}/>
        <div style={{position:"relative",zIndex:1}}>
          <div style={{display:"inline-flex",alignItems:"center",gap:8,padding:"6px 18px",border:"1px solid rgba(200,144,42,0.35)",borderRadius:50,color:"rgba(240,220,180,0.8)",fontSize:12,marginBottom:24}}>✦ Energía consagrada · Envío en zona seleccionada</div>
          <h1 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"clamp(2.4rem,8vw,4rem)",fontWeight:300,color:"#f0e8d4",lineHeight:1.1,marginBottom:8}}>Rituales que<br/><em style={{color:"#e0aa4a"}}>despiertan</em></h1>
          <p style={{color:"rgba(240,220,180,0.55)",fontSize:14,maxWidth:320,margin:"20px auto 0",lineHeight:1.7}}>Velas, cuarzos, inciensos y herramientas místicas elegidas a mano.</p>
        </div>
      </div>

      {/* CATÁLOGO */}
      <div style={{maxWidth:480,margin:"0 auto",padding:"40px 16px 100px"}}>
        <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"2rem",fontWeight:400,marginBottom:20}}>Catálogo</h2>
        <div style={{position:"relative",marginBottom:18}}>
          <span style={{position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",fontSize:14}}>🔍</span>
          <input value={busq} onChange={e=>setBusq(e.target.value)} placeholder="Buscar producto…" style={{width:"100%",padding:"12px 14px 12px 40px",border:"1.5px solid #e0d8cc",borderRadius:50,fontFamily:"'Jost',sans-serif",fontSize:14,outline:"none",background:"white"}}/>
        </div>
        <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:28}}>
          {cats.map(c=>(
            <button key={c} onClick={()=>setFiltro(c)} style={{padding:"7px 16px",borderRadius:50,border:`1.5px solid ${filtro===c?"#c8902a":"#e0d8cc"}`,background:filtro===c?"#c8902a":"white",color:filtro===c?"white":"#2e2416",cursor:"pointer",fontSize:13,fontFamily:"'Jost',sans-serif"}}>{c}</button>
          ))}
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:16}}>
          {visibles.length===0 && <div style={{textAlign:"center",padding:60,color:"#7a6e60"}}>🌙 Sin productos en esta categoría</div>}
          {visibles.map(p=>(
            <div key={p.id} style={{background:"white",borderRadius:20,border:"1px solid #e0d8cc",overflow:"hidden"}}>
              <div style={{width:"100%",aspectRatio:"4/3",background:p.imagen_url?`url(${p.imagen_url}) center/cover`:"#f0ecf5",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"3.5rem",backgroundSize:"cover"}}>{!p.imagen_url&&(p.emoji||"✨")}</div>
              <div style={{padding:"14px 16px 16px"}}>
                <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.3rem",marginBottom:4}}>{p.nombre}</div>
                <div style={{fontSize:13,color:"#7a6e60",marginBottom:12,lineHeight:1.5}}>{p.descripcion}</div>
                {p.stock<=3&&p.stock>0&&<div style={{fontSize:11,color:"#c8902a",marginBottom:8}}>⚡ Últimas {p.stock} unidades</div>}
                {p.stock===0&&<div style={{fontSize:11,color:"#999",marginBottom:8}}>Sin stock</div>}
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                  <span style={{fontSize:"1.1rem",fontWeight:500,color:"#c8902a"}}>${p.precio}.00</span>
                  <button onClick={()=>agregar(p)} disabled={p.stock===0} style={{padding:"9px 22px",borderRadius:50,border:"none",background:enCarrito(p.id)?"#1a1510":"#c8902a",color:"white",cursor:p.stock===0?"not-allowed":"pointer",fontSize:13,fontFamily:"'Jost',sans-serif",opacity:p.stock===0?0.4:1}}>
                    {enCarrito(p.id)?"✓ Agregado":"Agregar"}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* DRAWER CARRITO */}
      {drawerOpen&&<div onClick={()=>setDrawerOpen(false)} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.4)",zIndex:200}}/>}
      <div style={{position:"fixed",right:0,top:0,bottom:0,width:"min(92vw,390px)",background:"#faf7f2",zIndex:201,transform:drawerOpen?"translateX(0)":"translateX(100%)",transition:"transform 0.35s cubic-bezier(0.4,0,0.2,1)",display:"flex",flexDirection:"column",boxShadow:"-20px 0 60px rgba(0,0,0,0.15)"}}>
        <div style={{padding:"18px 20px 14px",borderBottom:"1px solid #e0d8cc",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.4rem",fontWeight:600}}>☽ Tu Carrito</span>
          <button onClick={()=>setDrawerOpen(false)} style={{width:34,height:34,border:"1.5px solid #e0d8cc",borderRadius:"50%",background:"transparent",cursor:"pointer",fontSize:14,color:"#7a6e60"}}>✕</button>
        </div>
        <div style={{flex:1,overflowY:"auto",padding:"14px 20px"}}>
          {carrito.length===0
            ?<div style={{textAlign:"center",padding:"50px 0",color:"#7a6e60"}}>🌙 Tu carrito está vacío</div>
            :carrito.map(p=>(
              <div key={p.id} style={{display:"flex",gap:12,alignItems:"center",padding:"10px 0",borderBottom:"1px solid #e0d8cc"}}>
                <div style={{width:48,height:48,background:p.imagen_url?`url(${p.imagen_url}) center/cover`:"#f0ecf5",backgroundSize:"cover",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.3rem",flexShrink:0}}>{!p.imagen_url&&p.emoji}</div>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:15,fontWeight:600}}>{p.nombre}</div>
                  <div style={{fontSize:12,color:"#c8902a"}}>${p.precio}</div>
                </div>
                <button onClick={()=>quitar(p.id)} style={{background:"none",border:"none",cursor:"pointer",color:"#bbb",fontSize:14}}>✕</button>
              </div>
            ))
          }
          {carrito.length>0&&(
            <div style={{marginTop:20}}>
              <div style={{fontSize:11,color:"#7a6e60",letterSpacing:"0.06em",marginBottom:10}}>👤 TUS DATOS</div>
              {[{key:"nombre",ph:"Nombre completo"},{key:"telefono",ph:"Teléfono"}].map(f=>(
                <input key={f.key} value={addr[f.key]} onChange={e=>setAddr(a=>({...a,[f.key]:e.target.value}))} placeholder={f.ph}
                  style={{width:"100%",padding:"9px 12px",border:"1.5px solid #e0d8cc",borderRadius:10,fontFamily:"'Jost',sans-serif",fontSize:13,outline:"none",marginBottom:8,background:"white"}}/>
              ))}
              <div style={{fontSize:11,color:"#7a6e60",letterSpacing:"0.06em",margin:"12px 0 10px"}}>📍 DIRECCIÓN DE ENTREGA</div>
              {[{key:"calle",ph:"Calle y número"},{key:"colonia",ph:"Colonia"}].map(f=>(
                <input key={f.key} value={addr[f.key]} onChange={e=>setAddr(a=>({...a,[f.key]:e.target.value}))} placeholder={f.ph}
                  style={{width:"100%",padding:"9px 12px",border:"1.5px solid #e0d8cc",borderRadius:10,fontFamily:"'Jost',sans-serif",fontSize:13,outline:"none",marginBottom:8,background:"white"}}/>
              ))}
              <div style={{display:"flex",gap:8,marginBottom:8}}>
                <input value={addr.cp} onChange={e=>{const v=e.target.value.replace(/\D/g,"").slice(0,5);verificarCP(v);}} placeholder="Código postal" maxLength={5}
                  style={{flex:1,padding:"9px 12px",border:`1.5px solid ${cpStatus==="inside"?"#2d7a2d":cpStatus==="outside"?"#c8902a":"#e0d8cc"}`,borderRadius:10,fontFamily:"'Jost',sans-serif",fontSize:13,outline:"none",background:"white"}}/>
                <input value={addr.alcaldia} readOnly placeholder="Alcaldía"
                  style={{flex:1,padding:"9px 12px",border:"1.5px solid #e0d8cc",borderRadius:10,fontFamily:"'Jost',sans-serif",fontSize:13,outline:"none",background:"#f5f0e8",color:"#7a6e60"}}/>
              </div>
              <input value={addr.refs} onChange={e=>setAddr(a=>({...a,refs:e.target.value}))} placeholder="Referencias"
                style={{width:"100%",padding:"9px 12px",border:"1.5px solid #e0d8cc",borderRadius:10,fontFamily:"'Jost',sans-serif",fontSize:13,outline:"none",background:"white"}}/>
              {cpStatus==="inside"&&<div style={{marginTop:8,padding:"8px 12px",background:"rgba(34,139,34,0.08)",border:"1px solid rgba(34,139,34,0.2)",borderRadius:10,fontSize:12,color:"#2d7a2d"}}>✅ Zona con cobertura — Envío sin costo</div>}
              {cpStatus==="outside"&&<div style={{marginTop:8,padding:"8px 12px",background:"rgba(200,144,42,0.08)",border:"1px solid rgba(200,144,42,0.25)",borderRadius:10,fontSize:12,color:"#8a6010"}}>📦 Fuera de zona — Envío por paquetería</div>}
            </div>
          )}
        </div>
        <div style={{padding:"14px 20px 20px",borderTop:"1px solid #e0d8cc"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:14,fontSize:14}}>
            <span style={{color:"#7a6e60"}}>Total</span>
            <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.3rem",fontWeight:600}}>${total}</span>
          </div>
          <button onClick={confirmarPedido} disabled={!carrito.length||enviando}
            style={{width:"100%",padding:14,background:"#1a1510",color:"#faf7f2",border:"none",borderRadius:50,fontFamily:"'Jost',sans-serif",fontSize:14,fontWeight:500,cursor:carrito.length&&!enviando?"pointer":"not-allowed",opacity:carrito.length&&!enviando?1:0.5,letterSpacing:"0.04em"}}>
            {enviando?"Enviando…":"Confirmar pedido 📲"}
          </button>
        </div>
      </div>

      {/* FAQ */}
      <button onClick={()=>{setFaqOpen(o=>!o);setFaqIdx(null);}} style={{position:"fixed",bottom:20,right:20,width:50,height:50,background:faqOpen?"#1a1510":"#c8902a",border:"none",borderRadius:"50%",cursor:"pointer",zIndex:400,fontSize:20,boxShadow:"0 4px 20px rgba(0,0,0,0.25)",transition:"all 0.2s"}}>
        {faqOpen?"✕":"💬"}
      </button>
      {faqOpen&&(
        <div style={{position:"fixed",bottom:82,right:16,width:"min(92vw,330px)",background:"#faf7f2",borderRadius:20,zIndex:399,boxShadow:"0 12px 50px rgba(0,0,0,0.2)",border:"1px solid #e0d8cc",overflow:"hidden",maxHeight:"65vh",display:"flex",flexDirection:"column"}}>
          <div style={{background:"#1a1510",padding:"14px 18px",display:"flex",alignItems:"center",gap:10}}>
            <span style={{fontSize:20}}>☽</span>
            <div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",color:"#f0e8d4",fontSize:15,fontWeight:600}}>Preguntas frecuentes</div>
              <div style={{fontSize:11,color:"rgba(240,220,180,0.5)"}}>Toca para ver la respuesta</div>
            </div>
          </div>
          <div style={{flex:1,overflowY:"auto",padding:"12px 14px"}}>
            {FAQS.map((f,i)=>(
              <div key={i} style={{marginBottom:8}}>
                <button onClick={()=>setFaqIdx(faqIdx===i?null:i)} style={{width:"100%",textAlign:"left",padding:"10px 14px",background:faqIdx===i?"#1a1510":"white",color:faqIdx===i?"#f0e8d4":"#2e2416",border:`1.5px solid ${faqIdx===i?"#c8902a":"#e0d8cc"}`,borderRadius:faqIdx===i?"12px 12px 0 0":12,cursor:"pointer",fontFamily:"'Jost',sans-serif",fontSize:13,fontWeight:500,display:"flex",justifyContent:"space-between"}}>
                  {f.q}<span style={{color:"#c8902a",marginLeft:8}}>{faqIdx===i?"−":"+"}</span>
                </button>
                {faqIdx===i&&<div style={{padding:"10px 14px",background:"#f5f0e8",border:"1.5px solid #c8902a",borderTop:"none",borderRadius:"0 0 12px 12px",fontSize:13,lineHeight:1.6}}>{f.a}</div>}
              </div>
            ))}
            <div style={{margin:"8px 0 4px",padding:"12px 14px",background:"rgba(200,144,42,0.07)",border:"1px solid rgba(200,144,42,0.25)",borderRadius:12,textAlign:"center"}}>
              <div style={{fontSize:12,color:"#7a6e60",marginBottom:6}}>¿No encontraste tu respuesta?</div>
              <a href="https://wa.me/525648229075" target="_blank" rel="noopener noreferrer" style={{color:"#c8902a",fontWeight:700,fontSize:15,textDecoration:"none"}}>📱 5648229075</a>
            </div>
          </div>
        </div>
      )}

      <button onClick={onAdmin} style={{position:"fixed",bottom:20,left:20,width:32,height:32,background:"rgba(0,0,0,0.1)",border:"none",borderRadius:"50%",cursor:"pointer",fontSize:13,color:"rgba(0,0,0,0.2)",zIndex:50}} title="Admin">⚙</button>
      {toast&&<Toast msg={toast}/>}
    </div>
  );
};

// ─── PANEL ADMIN ──────────────────────────────────────────────────────────────
const Admin = ({ onSalir }) => {
  const [seccion, setSeccion] = useState("pedidos");
  const [pedidos, setPedidos] = useState([]);
  const [productos, setProductos] = useState([]);
  const [config, setConfig] = useState([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState("");
  const [detalle, setDetalle] = useState(null);
  const [editProd, setEditProd] = useState(null);
  const [filtroSt, setFiltroSt] = useState("todos");

  const showToast = msg => { setToast(msg); setTimeout(()=>setToast(""),2500); };

  const cargar = useCallback(async()=>{
    setLoading(true);
    const [peds,prods,cfg] = await Promise.all([
      query("pedidos","?select=*&order=created_at.desc"),
      query("productos","?select=*&order=id.asc"),
      query("config","?select=*"),
    ]);
    setPedidos(Array.isArray(peds)?peds:[]);
    setProductos(Array.isArray(prods)?prods:[]);
    setConfig(Array.isArray(cfg)?cfg:[]);
    setLoading(false);
  },[]);

  useEffect(()=>{cargar();},[cargar]);

  const hoy = new Date().toISOString().slice(0,10);
  const pedidosHoy = pedidos.filter(p=>p.created_at?.slice(0,10)===hoy);
  const ventasHoy = pedidosHoy.filter(p=>p.status!=="cancelado").reduce((s,p)=>s+Number(p.total),0);
  const nuevos = pedidos.filter(p=>p.status==="nuevo").length;

  const cambiarStatus = async(id,status)=>{
    await mutate("pedidos","PATCH",{status},`?id=eq.${id}`);
    setPedidos(pr=>pr.map(p=>p.id===id?{...p,status}:p));
    if(detalle?.id===id) setDetalle(pr=>({...pr,status}));
    showToast("✦ Status actualizado");
  };

  const guardarProducto = async(form)=>{
    const d={nombre:form.nombre,descripcion:form.descripcion,precio:Number(form.precio),stock:Number(form.stock),categoria:form.categoria,emoji:form.emoji,activo:form.activo};
    if(form.id){
      await mutate("productos","PATCH",d,`?id=eq.${form.id}`);
      setProductos(pr=>pr.map(p=>p.id===form.id?{...p,...d}:p));
    } else {
      const n=await mutate("productos","POST",d);
      if(Array.isArray(n)) setProductos(pr=>[...pr,n[0]]);
    }
    setEditProd(null); showToast("✦ Producto guardado");
  };

  const guardarConfig = async(items)=>{
    await Promise.all(items.map(i=>mutate("config","PATCH",{valor:i.valor},`?clave=eq.${i.clave}`)));
    setConfig(items); showToast("✦ Config guardada");
  };

  const pedFiltrados = filtroSt==="todos"?pedidos:pedidos.filter(p=>p.status===filtroSt);

  if(loading) return <div style={{height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#f5f0e8"}}><Spinner/></div>;

  return (
    <div style={{fontFamily:"'Jost',sans-serif",background:"#f5f0e8",minHeight:"100vh",color:"#2e2416"}}>
      <link href={GF} rel="stylesheet"/>
      <div style={{background:"#1a1510",padding:"14px 20px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:"#f0e8d4",fontWeight:600}}>☽ Aether <span style={{color:"#c8902a",fontSize:13,fontWeight:400}}>Admin</span></div>
        <button onClick={onSalir} style={{fontSize:12,color:"rgba(240,220,180,0.6)",background:"none",border:"1px solid rgba(240,220,180,0.2)",borderRadius:50,padding:"5px 14px",cursor:"pointer",fontFamily:"'Jost',sans-serif"}}>Ver tienda</button>
      </div>

      {/* STATS */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,padding:"16px 16px 0",maxWidth:480,margin:"0 auto"}}>
        {[{l:"Pedidos hoy",v:pedidosHoy.length,i:"📦"},{l:"Ventas hoy",v:`$${ventasHoy}`,i:"💰"},{l:"Sin confirmar",v:nuevos,i:"🆕"}].map(s=>(
          <div key={s.l} style={{background:"white",borderRadius:14,padding:"12px 10px",textAlign:"center",border:"1px solid #e0d8cc"}}>
            <div style={{fontSize:20,marginBottom:4}}>{s.i}</div>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.3rem",fontWeight:600,color:"#1a1510"}}>{s.v}</div>
            <div style={{fontSize:11,color:"#7a6e60"}}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* TABS */}
      <div style={{display:"flex",borderBottom:"2px solid #e0d8cc",background:"white",padding:"0 16px",maxWidth:480,margin:"16px auto 0"}}>
        {[["pedidos","📋 Pedidos"],["productos","📦 Productos"],["config","⚙️ Config"]].map(([k,l])=>(
          <button key={k} onClick={()=>setSeccion(k)} style={{padding:"13px 14px",border:"none",background:"transparent",cursor:"pointer",fontFamily:"'Jost',sans-serif",fontSize:13,fontWeight:500,color:seccion===k?"#c8902a":"#7a6e60",borderBottom:seccion===k?"2px solid #c8902a":"2px solid transparent",marginBottom:-2}}>{l}</button>
        ))}
      </div>

      <div style={{maxWidth:480,margin:"0 auto",padding:"20px 16px 80px"}}>
        {seccion==="pedidos"&&(
          <>
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:16}}>
              {[["todos","Todos"],["nuevo","🆕 Nuevos"],["confirmado","✅ Confirmados"],["enviado","🚚 Enviados"],["entregado","🏠 Entregados"],["cancelado","❌ Cancelados"]].map(([k,l])=>(
                <button key={k} onClick={()=>setFiltroSt(k)} style={{padding:"5px 12px",borderRadius:50,border:`1.5px solid ${filtroSt===k?"#c8902a":"#e0d8cc"}`,background:filtroSt===k?"#c8902a":"white",color:filtroSt===k?"white":"#2e2416",cursor:"pointer",fontSize:12,fontFamily:"'Jost',sans-serif"}}>{l}</button>
              ))}
            </div>
            {pedFiltrados.length===0&&<div style={{textAlign:"center",padding:60,color:"#7a6e60"}}>🌙 Sin pedidos</div>}
            {pedFiltrados.map(p=>(
              <div key={p.id} onClick={()=>setDetalle(p)} style={{background:"white",borderRadius:16,border:"1px solid #e0d8cc",padding:"14px 16px",marginBottom:10,cursor:"pointer"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                  <div>
                    <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:17,fontWeight:600}}>{p.folio}</div>
                    <div style={{fontSize:12,color:"#7a6e60"}}>{p.cliente_nombre} · {p.cliente_telefono}</div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:16,fontWeight:600,color:"#c8902a"}}>${p.total}</div>
                    <span style={{fontSize:11,padding:"2px 8px",borderRadius:50,background:STATUS_COLORS[p.status]+"22",color:STATUS_COLORS[p.status],border:`1px solid ${STATUS_COLORS[p.status]}44`}}>{STATUS_LABELS[p.status]}</span>
                  </div>
                </div>
                <div style={{fontSize:12,color:"#7a6e60"}}>{p.tipo_envio==="cobertura"?"🚚 Envío sin costo":"📦 Paquetería"} · {new Date(p.created_at).toLocaleDateString("es-MX",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"})}</div>
              </div>
            ))}
          </>
        )}

        {seccion==="productos"&&(
          <>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.5rem"}}>Productos</div>
              <button onClick={()=>setEditProd({id:null,nombre:"",descripcion:"",precio:0,stock:0,categoria:CATS[0],emoji:"✨",activo:true})} style={{padding:"8px 16px",background:"#c8902a",color:"white",border:"none",borderRadius:50,cursor:"pointer",fontSize:13,fontFamily:"'Jost',sans-serif"}}>+ Nuevo</button>
            </div>
            {productos.map(p=>(
              <div key={p.id} style={{background:"white",borderRadius:14,border:"1px solid #e0d8cc",padding:"12px 14px",marginBottom:10,display:"flex",gap:12,alignItems:"center"}}>
                <div style={{width:52,height:52,borderRadius:10,background:p.imagen_url?`url(${p.imagen_url}) center/cover`:"#f0ecf5",backgroundSize:"cover",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.5rem",flexShrink:0}}>{!p.imagen_url&&p.emoji}</div>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:15,fontWeight:600}}>{p.nombre}</div>
                  <div style={{fontSize:12,color:"#7a6e60",display:"flex",gap:8,marginTop:3}}>
                    <span style={{color:"#c8902a",fontWeight:500}}>${p.precio}</span>
                    <span style={{color:p.stock>3?"#2d7a2d":p.stock>0?"#c8902a":"#999"}}>Stock: {p.stock}</span>
                    {!p.activo&&<span style={{color:"#999"}}>Oculto</span>}
                  </div>
                </div>
                <button onClick={()=>setEditProd({...p})} style={{padding:"6px 14px",border:"1.5px solid #e0d8cc",borderRadius:50,background:"transparent",cursor:"pointer",fontSize:12,fontFamily:"'Jost',sans-serif"}}>Editar</button>
              </div>
            ))}
          </>
        )}

        {seccion==="config"&&<ConfigForm config={config} onGuardar={guardarConfig}/>}
      </div>

      {detalle&&<DetallePedido pedido={detalle} onCerrar={()=>setDetalle(null)} onCambiarStatus={cambiarStatus}/>}
      {editProd&&<EditorProducto prod={editProd} onGuardar={guardarProducto} onCerrar={()=>setEditProd(null)}/>}
      {toast&&<Toast msg={toast}/>}
    </div>
  );
};

// ─── DETALLE PEDIDO ───────────────────────────────────────────────────────────
const DetallePedido = ({ pedido, onCerrar, onCambiarStatus }) => {
  const [items, setItems] = useState([]);
  useEffect(()=>{ query("pedido_items",`?pedido_id=eq.${pedido.id}&select=*`).then(r=>setItems(Array.isArray(r)?r:[])); },[pedido.id]);

  const notifWA = () => {
    const msgs = { confirmado:"✅ Tu pedido ha sido *confirmado*. Te enviaremos los datos de pago en breve.", enviado:"🚚 Tu pedido está *en camino*. ¡Pronto llegará!", entregado:"🏠 Tu pedido fue *entregado*. ¡Gracias por tu compra en Aether! ☽" };
    const m = msgs[pedido.status]||"Tu pedido ha sido actualizado.";
    const msg = encodeURIComponent(`Hola ${pedido.cliente_nombre} 🌙\n\n${m}\n\nFolio: *${pedido.folio}*\nTotal: $${pedido.total}\n\n— Aether ☽`);
    window.open(`https://wa.me/52${pedido.cliente_telefono}?text=${msg}`,"_blank");
  };

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:500,display:"flex",alignItems:"flex-end",justifyContent:"center"}}>
      <div style={{background:"#faf7f2",borderRadius:"24px 24px 0 0",width:"100%",maxWidth:480,maxHeight:"88vh",overflowY:"auto",padding:"24px 20px 32px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
          <div>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.4rem",fontWeight:600}}>{pedido.folio}</div>
            <div style={{fontSize:12,color:"#7a6e60"}}>{new Date(pedido.created_at).toLocaleDateString("es-MX",{dateStyle:"full"})}</div>
          </div>
          <button onClick={onCerrar} style={{background:"none",border:"none",fontSize:20,cursor:"pointer",color:"#7a6e60"}}>✕</button>
        </div>

        <div style={{background:"white",borderRadius:14,border:"1px solid #e0d8cc",padding:"14px 16px",marginBottom:14}}>
          <div style={{fontSize:11,color:"#7a6e60",letterSpacing:"0.06em",marginBottom:10}}>👤 CLIENTE</div>
          <div style={{fontSize:14,fontWeight:500}}>{pedido.cliente_nombre}</div>
          <div style={{fontSize:13,color:"#7a6e60"}}>📞 {pedido.cliente_telefono}</div>
          <div style={{fontSize:13,color:"#7a6e60",marginTop:6}}>📍 {pedido.cliente_calle}, Col. {pedido.cliente_colonia}, CP {pedido.cliente_cp}{pedido.cliente_alcaldia?`, ${pedido.cliente_alcaldia}`:""}</div>
          {pedido.cliente_referencias&&<div style={{fontSize:12,color:"#7a6e60"}}>Refs: {pedido.cliente_referencias}</div>}
          <div style={{marginTop:8,fontSize:12}}>{pedido.tipo_envio==="cobertura"?"🚚 Envío sin costo":"📦 Envío por paquetería"}</div>
        </div>

        <div style={{background:"white",borderRadius:14,border:"1px solid #e0d8cc",padding:"14px 16px",marginBottom:14}}>
          <div style={{fontSize:11,color:"#7a6e60",letterSpacing:"0.06em",marginBottom:10}}>📦 PRODUCTOS</div>
          {items.map(item=>(
            <div key={item.id} style={{display:"flex",justifyContent:"space-between",fontSize:13,padding:"6px 0",borderBottom:"1px solid #f0ece6"}}>
              <span>{item.nombre} ×{item.cantidad}</span>
              <span style={{color:"#c8902a",fontWeight:500}}>${item.precio*item.cantidad}</span>
            </div>
          ))}
          <div style={{display:"flex",justifyContent:"space-between",marginTop:10,fontWeight:600,fontSize:15}}>
            <span>Total</span><span style={{color:"#c8902a"}}>${pedido.total}</span>
          </div>
        </div>

        <div style={{marginBottom:16}}>
          <div style={{fontSize:11,color:"#7a6e60",letterSpacing:"0.06em",marginBottom:10}}>CAMBIAR STATUS</div>
          <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
            {Object.entries(STATUS_LABELS).map(([k,l])=>(
              <button key={k} onClick={()=>onCambiarStatus(pedido.id,k)}
                style={{padding:"8px 14px",borderRadius:50,border:`1.5px solid ${pedido.status===k?STATUS_COLORS[k]:"#e0d8cc"}`,background:pedido.status===k?STATUS_COLORS[k]+"22":"white",color:pedido.status===k?STATUS_COLORS[k]:"#2e2416",cursor:"pointer",fontSize:12,fontFamily:"'Jost',sans-serif",fontWeight:pedido.status===k?600:400}}>
                {l}
              </button>
            ))}
          </div>
        </div>

        <button onClick={notifWA} style={{width:"100%",padding:13,background:"#25D366",color:"white",border:"none",borderRadius:50,fontFamily:"'Jost',sans-serif",fontSize:14,cursor:"pointer",fontWeight:500}}>
          Notificar al cliente por WhatsApp 📲
        </button>
      </div>
    </div>
  );
};

// ─── EDITOR PRODUCTO ──────────────────────────────────────────────────────────
const EditorProducto = ({ prod, onGuardar, onCerrar }) => {
  const [form, setForm] = useState({...prod});
  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:500,display:"flex",alignItems:"flex-end",justifyContent:"center"}}>
      <div style={{background:"#faf7f2",borderRadius:"24px 24px 0 0",width:"100%",maxWidth:480,maxHeight:"88vh",overflowY:"auto",padding:"24px 20px 32px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
          <h3 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.4rem"}}>{form.id?"Editar producto":"Nuevo producto"}</h3>
          <button onClick={onCerrar} style={{background:"none",border:"none",fontSize:20,cursor:"pointer",color:"#7a6e60"}}>✕</button>
        </div>
        {[{l:"Nombre",k:"nombre"},{l:"Descripción",k:"descripcion"},{l:"Precio ($)",k:"precio",n:true},{l:"Stock",k:"stock",n:true},{l:"Emoji",k:"emoji"}].map(f=>(
          <div key={f.k} style={{marginBottom:12}}>
            <label style={{fontSize:12,color:"#7a6e60",display:"block",marginBottom:4}}>{f.l}</label>
            <input type={f.n?"number":"text"} value={form[f.k]} onChange={e=>set(f.k,f.n?Number(e.target.value):e.target.value)}
              style={{width:"100%",padding:"10px 14px",border:"1.5px solid #e0d8cc",borderRadius:10,fontFamily:"'Jost',sans-serif",fontSize:14,outline:"none",background:"white"}}/>
          </div>
        ))}
        <div style={{marginBottom:12}}>
          <label style={{fontSize:12,color:"#7a6e60",display:"block",marginBottom:4}}>Categoría</label>
          <select value={form.categoria} onChange={e=>set("categoria",e.target.value)} style={{width:"100%",padding:"10px 14px",border:"1.5px solid #e0d8cc",borderRadius:10,fontFamily:"'Jost',sans-serif",fontSize:14,outline:"none",background:"white"}}>
            {CATS.map(c=><option key={c}>{c}</option>)}
          </select>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:20}}>
          <input type="checkbox" id="act" checked={form.activo} onChange={e=>set("activo",e.target.checked)}/>
          <label htmlFor="act" style={{fontSize:14,cursor:"pointer"}}>Visible en tienda</label>
        </div>
        <button onClick={()=>onGuardar(form)} style={{width:"100%",padding:13,background:"#1a1510",color:"white",border:"none",borderRadius:50,fontFamily:"'Jost',sans-serif",fontSize:14,cursor:"pointer",fontWeight:500}}>Guardar</button>
      </div>
    </div>
  );
};

// ─── CONFIG FORM ──────────────────────────────────────────────────────────────
const ConfigForm = ({ config, onGuardar }) => {
  const [items, setItems] = useState(config.map(c=>({...c})));
  const labels = { whatsapp:"WhatsApp (con código de país)", banco:"Banco", titular:"Titular de cuenta", clabe:"CLABE (18 dígitos)", cuenta:"Número de cuenta", concepto:"Concepto de pago" };
  const set = (clave,valor) => setItems(pr=>pr.map(i=>i.clave===clave?{...i,valor}:i));
  return (
    <div style={{background:"white",borderRadius:16,border:"1px solid #e0d8cc",padding:20}}>
      <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.3rem",marginBottom:20}}>Cuenta bancaria y contacto</div>
      {items.map(item=>(
        <div key={item.clave} style={{marginBottom:14}}>
          <label style={{fontSize:12,color:"#7a6e60",display:"block",marginBottom:4}}>{labels[item.clave]||item.clave}</label>
          <input value={item.valor||""} onChange={e=>set(item.clave,e.target.value)} style={{width:"100%",padding:"10px 14px",border:"1.5px solid #e0d8cc",borderRadius:10,fontFamily:"'Jost',sans-serif",fontSize:14,outline:"none",background:"#faf7f2"}}/>
        </div>
      ))}
      <button onClick={()=>onGuardar(items)} style={{width:"100%",padding:13,background:"#1a1510",color:"white",border:"none",borderRadius:50,fontFamily:"'Jost',sans-serif",fontSize:14,cursor:"pointer",fontWeight:500,marginTop:4}}>Guardar configuración</button>
    </div>
  );
};

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
export default function App() {
  const [vista, setVista] = useState("tienda");
  const [pin, setPin] = useState("");
  const [pinError, setPinError] = useState(false);

  const entrar = () => {
    if(pin===PIN_ADMIN){ setVista("admin"); setPin(""); setPinError(false); }
    else { setPinError(true); setPin(""); }
  };

  if(vista==="pin") return (
    <div style={{height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#1a1208",flexDirection:"column",gap:20,padding:24}}>
      <link href={GF} rel="stylesheet"/>
      <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"2rem",color:"#e0aa4a"}}>☽ Admin</div>
      <input type="password" value={pin} onChange={e=>setPin(e.target.value)} onKeyDown={e=>e.key==="Enter"&&entrar()} placeholder="PIN" maxLength={6}
        style={{padding:"12px 20px",border:`2px solid ${pinError?"#c0392b":"rgba(200,144,42,0.3)"}`,borderRadius:50,background:"transparent",color:"white",fontFamily:"'Jost',sans-serif",fontSize:18,outline:"none",textAlign:"center",letterSpacing:"0.3em",width:200}}/>
      {pinError&&<div style={{color:"#e74c3c",fontSize:13}}>PIN incorrecto</div>}
      <button onClick={entrar} style={{padding:"12px 32px",background:"#c8902a",color:"white",border:"none",borderRadius:50,fontFamily:"'Jost',sans-serif",fontSize:14,cursor:"pointer",fontWeight:500}}>Entrar</button>
      <button onClick={()=>setVista("tienda")} style={{color:"rgba(240,220,180,0.4)",background:"none",border:"none",cursor:"pointer",fontSize:13}}>Volver a la tienda</button>
    </div>
  );

  if(vista==="admin") return <Admin onSalir={()=>setVista("tienda")}/>;
  return <Tienda onAdmin={()=>setVista("pin")}/>;
}
