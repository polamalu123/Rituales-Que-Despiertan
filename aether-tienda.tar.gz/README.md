# ☽ Aether — Tienda Esotérica

Tienda virtual conectada a Supabase con panel de pedidos.

## Tecnologías
- React 18
- Supabase (base de datos)
- Vercel (hosting)
